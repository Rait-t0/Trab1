import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import static javax.swing.JOptionPane.showMessageDialog;

public class Formulario_Instituciones extends JFrame {

    private JPanel Panel_Instituciones;
    private JButton But_Mostrar;
    private JButton But_Nuevo;
    private JButton But_Modificar;
    private JButton But_Eliminar;
    private JTable tabla_institucion;
    private JTextField Text_Codigo;
    private JTextField Text_Nombre;
    private JTextField Text_Direccion;
    private JButton guardarButton;
    private JTextField Text_Distrito;
    private JTextField Text_Nivel;
    private JTextField Text_Gestion;
    private JComboBox Combo_Bus;
    private JTextField Text_Bus;

    String url = "jdbc:mysql://localhost:3306/ugel_san_roman";
    String usuario_bd = "root";
    String password_bd = "";

    public Formulario_Instituciones() { // Inicio del constructor
        setContentPane(Panel_Instituciones); // Agregamos el panel Principal
        setTitle("Formulario de las Instituciones"); // Titulo del formulario
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // Accion para cerrar la ventana
        setLocationRelativeTo(null); // Centrado del formulario en pantalla
        setSize(800, 400); // Tamaño del formulario
        setResizable(true); // Para que el usuario no pueda modificar el tamaño del formulario
        setVisible(true); // Para visualizar el formulario en pantalla

        But_Mostrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                Connection PruebaConexion = null;
                PruebaConexion = metodo_conexion();

                if (PruebaConexion != null) {
                    showMessageDialog(null,"Se a conectaro al BD");
                    System.out.println("Se a conectaro al BD");

                    Statement statement = null; //sirve para instrucciones SQL
                    ResultSet resultset = null; //es para el conjunto de registros

                    System.out.println("conectando");

                    try {
                        statement = PruebaConexion.createStatement();
                        resultset = statement.executeQuery("SELECT * FROM institución");

                        DefaultTableModel modelo = new DefaultTableModel();
                        modelo.setColumnIdentifiers(new Object[]{"Id","Codigo Modular", "Nombre", "Direccion","Distrito","Nivel","Gestion"});
                        modelo.setRowCount(0);

                        while (resultset.next()) {
                            Object[] fila = new Object[7];
                            fila[0] = resultset.getInt("id");
                            fila[1] = resultset.getInt("codigo");
                            fila[2] = resultset.getString("nombre");
                            fila[3] = resultset.getString("direccion");
                            fila[4] = resultset.getString("distrito");
                            fila[5] = resultset.getString("nivel");
                            fila[6] = resultset.getString("gestion");
                            modelo.addRow(fila);
                        }

                        tabla_institucion.setModel(modelo);

                    } catch (SQLException ex) {
                        System.out.println("Error al acceder a la tabla de instituciones");
                    }
                } else {
                    System.out.println("No se encontró la conexión");
                }
            }
        });

        guardarButton.addActionListener(new ActionListener() { //Inicio del boton GUARDAR
            @Override
            public void actionPerformed(ActionEvent e) {
                //Primero nos conectamos a la base de datos
                Connection Laconexion = null;
                Laconexion = metodo_conexion();

                if (Laconexion != null) {
                    System.out.println("conectado exitosamente a la base de datos");
                    //las variables no tienes que ser necesariamente las mismas
                    String te_codigo = Text_Codigo.getText();
                    String te_nombre  = Text_Nombre.getText();
                    String te_direccion   = Text_Direccion.getText();
                    String te_distrito = Text_Distrito.getText();
                    String te_nivel = Text_Nivel.getText();
                    String te_gestion  = Text_Gestion.getText();

                    try{
                        String sql="INSERT INTO institución (codigo, nombre, direccion,distrito,nivel,gestion) VALUES(?,?,?,?,?,?)";//Esto si debe de coincidir con la tabla de la base de datos

                        PreparedStatement statement = Laconexion.prepareStatement(sql);
                        statement.setString(1, te_codigo);
                        statement.setString(2, te_nombre);
                        statement.setString(3, te_direccion);
                        statement.setString(4, te_distrito);
                        statement.setString(5, te_nivel);
                        statement.setString(6, te_gestion);
                        statement.execute();

                        JOptionPane.showMessageDialog(null, "Datos agregados exitosamente");

                    }catch (SQLException ex){
                        System.out.println(ex.getMessage());//para que nos de mas detalle del error
                        System.out.println("Error al agregar la institucion");
                    }
                } else{
                    System.out.println("No se pudo conectar con la base de datos");
                }
            }
        }); //  Fin del Boton GUARDAR
        But_Modificar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int filaSeleccionada = tabla_institucion.getSelectedRow();
                System.out.println("si ha seleccionado " + filaSeleccionada);
                if (filaSeleccionada == -1) {
                    JOptionPane.showMessageDialog(null, "Seleccione una institucion");
                }
                int id = Integer.parseInt(tabla_institucion.getValueAt(filaSeleccionada, 0).toString());
                String codi = tabla_institucion.getValueAt(filaSeleccionada, 1).toString();
                String nomb = tabla_institucion.getValueAt(filaSeleccionada, 2).toString();
                String dire = tabla_institucion.getValueAt(filaSeleccionada, 3).toString();
                String dist = tabla_institucion.getValueAt(filaSeleccionada, 4).toString();
                String nive = tabla_institucion.getValueAt(filaSeleccionada, 5).toString();
                String gest = tabla_institucion.getValueAt(filaSeleccionada, 6).toString();


                System.out.println(id + " " + codi + " " + nomb + " " + dire+ " " +dist
                        + " " +nive+ " " +gest);
                Connection Conexion_Modi = null;
                Conexion_Modi = metodo_conexion();

                Dialogo_Modificar ventanita = new Dialogo_Modificar(id, codi, nomb, dire,dist,nive,gest, Conexion_Modi);
                ventanita.setVisible(true);
            }
        });

        But_Eliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Connection LaConexion=null;
                LaConexion = metodo_conexion();
                if(LaConexion!=null){
                    int confirmacion = JOptionPane.showOptionDialog(null,
                            "Estas Seguro de Eliminar esta Institucion?",
                            "Cuidado!!!!",
                            JOptionPane.YES_NO_OPTION,
                            JOptionPane.QUESTION_MESSAGE,
                            null,
                            new Object[]{"Si, Eliminar","no"},
                            "No");
                    if (confirmacion != JOptionPane.YES_OPTION) {
                        return;
                    }
                    int filaSeleccionada = tabla_institucion.getSelectedRow();
                    System.out.println("Se ha seleccionado la fia:"+filaSeleccionada);

                    int id_producto = Integer.parseInt(tabla_institucion.getModel().getValueAt(filaSeleccionada, 0).toString());
                    try{

                        String sql="DELETE FROM institución WHERE id=?";
                        PreparedStatement statement = LaConexion.prepareStatement(sql);
                        statement.setInt(1, id_producto);
                        statement.execute();
                        JOptionPane.showMessageDialog(null, "Ta bien, felizmente tu libro se elimino exitosamente");
                    }catch (SQLException ex){
                        System.out.println(ex.getMessage());
                    }
                }
            }
        });
        But_Nuevo.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                System.out.println("Abriendo diálogo de nueva institución");

                int id = -1;
                String codi = "";
                String nomb = "";
                String dire = "";
                String dist = "";
                String nive = "";
                String gest = "";

                Connection Conexion_Nuevo = null;
                Conexion_Nuevo = metodo_conexion();


                Dialogo_Nuevo ventana_Nue = new Dialogo_Nuevo(id, codi, nomb, dire,dist,nive,gest, Conexion_Nuevo);
                ventana_Nue.setVisible(true);
            }
        });
    } // Fin del constructor

    public static void main(String[] args) {
        new Formulario_Instituciones();
    }

    public Connection metodo_conexion() {
        Connection conec = null;

        try {
            conec = DriverManager.getConnection(url, usuario_bd, password_bd);
        } catch (SQLException e) {
            System.out.println("Error al conectar con la base de datos");
        }
        return conec;
    }
}