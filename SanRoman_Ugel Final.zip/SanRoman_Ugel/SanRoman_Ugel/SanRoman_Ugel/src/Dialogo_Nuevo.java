import javax.swing.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Dialogo_Nuevo extends JDialog {
    private JPanel contentPane;
    private JButton buttonOK;
    private JButton buttonCancel;
    private JTextField Text_NCO;
    private JTextField Text_NNO;
    private JTextField Text_NDI;
    private JTextField Text_NDIS;
    private JTextField Text_NNI;
    private JTextField Text_NGE;

    public Dialogo_Nuevo(int id, String codi, String nomb, String dire, String dist, String nive,String gest, Connection cone) {
        setContentPane(contentPane);
        setModal(true);
        getRootPane().setDefaultButton(buttonOK);
        setSize(300,500);
        setLocationRelativeTo(null);

        //Colocamos los parametros recibidos en los cuadros de texto

        Text_NCO.setText(codi);
        Text_NNO.setText(nomb);
        Text_NDI.setText(dire);
        Text_NDIS.setText(dist);
        Text_NNI.setText(nive);
        Text_NGE.setText(gest);
        System.out.println("Id de la institucion: " + id);

        buttonOK.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String sql = "INSERT INTO institución (codigo_modular, nombre, direccion, distrito, nivel, gestion) VALUES (?, ?, ?, ?, ?, ?)";
                    PreparedStatement ps = cone.prepareStatement(sql);
                    ps.setString(1, Text_NCO.getText());
                    ps.setString(2, Text_NNO.getText());
                    ps.setString(3, Text_NDI.getText());
                    ps.setString(4, Text_NDIS.getText());
                    ps.setString(5, Text_NNI.getText());
                    ps.setString(6, Text_NGE.getText());

                    ps.executeUpdate();

                    JOptionPane.showMessageDialog(null, "Institución creada correctamente");

                    dispose();

                }catch (SQLException e1){
                    System.out.println("Error: " + e1.getMessage());
                    JOptionPane.showMessageDialog(null, "Error al crear la institución: " + e1.getMessage());
                }
            }
        });

        buttonCancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        });

        // call onCancel() when cross is clicked
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                onCancel();
            }
        });

        // call onCancel() on ESCAPE
        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
    }

    private void onCancel() {
        dispose();
    }
}

    /*public static void main(String[] args) {
        DialogModificar dialog = new DialogModificar();
        dialog.pack();
        dialog.setVisible(true);
        System.exit(0);
    }*/

