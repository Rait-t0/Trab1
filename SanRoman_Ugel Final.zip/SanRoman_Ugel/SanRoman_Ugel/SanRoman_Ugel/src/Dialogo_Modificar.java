import javax.swing.*;
import java.awt.event.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Dialogo_Modificar extends JDialog {
    private JPanel contentPane;
    private JButton buttonOK;
    private JButton buttonCancel;
    private JTextField Text_CO;
    private JTextField Text_NO;
    private JTextField Text_DI;
    private JTextField Text_DIS;
    private JTextField Text_NI;
    private JTextField Text_GE;

    public Dialogo_Modificar(int id, String codi, String nomb, String dire, String dist, String nive,String gest, Connection conec) {
        setContentPane(contentPane);
        setModal(true);
        getRootPane().setDefaultButton(buttonOK);
        setSize(300,500);
        setLocationRelativeTo(null);

        //Colocamos los parametros recibidos en los cuadros de texto

        Text_CO.setText(codi);
        Text_NO.setText(nomb);
        Text_DI.setText(dire);
        Text_DIS.setText(dist);
        Text_NI.setText(nive);
        Text_GE.setText(gest);
        System.out.println("Id del pruducto: " + id);

        buttonOK.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                try {
                    String sql = "UPDATE institución SET codigo=?, nombre=?, direccion=?,distrito=?,nivel=?,gestion=? WHERE id=?";
                    PreparedStatement ps = conec.prepareStatement(sql);
                    ps.setInt(1, Integer.parseInt(Text_CO.getText()));
                    ps.setString(2, Text_NO.getText());
                    ps.setString(3, Text_DI.getText());
                    ps.setString(4, Text_DIS.getText());
                    ps.setString(5, Text_NI.getText());
                    ps.setString(6, Text_GE.getText());
                    ps.setInt(7, id);

                    ps.executeUpdate();

                    JOptionPane.showMessageDialog(null, "Se actualizo correctamente");

                    dispose();

                }catch (SQLException e1){
                    System.out.println("Error: " + e1.getMessage());
                }
            }
        });

        buttonCancel.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        });

        // call onCancel() when cross is clicked
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                onCancel();
            }
        });

        // call onCancel() on ESCAPE
        contentPane.registerKeyboardAction(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                onCancel();
            }
        }, KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE, 0), JComponent.WHEN_ANCESTOR_OF_FOCUSED_COMPONENT);
    }

    private void onCancel() {
        // add your code here if necessary
        dispose();
    }

    /*public static void main(String[] args) {
        DialogModificar dialog = new DialogModificar();
        dialog.pack();
        dialog.setVisible(true);
        System.exit(0);
    }*/
}
